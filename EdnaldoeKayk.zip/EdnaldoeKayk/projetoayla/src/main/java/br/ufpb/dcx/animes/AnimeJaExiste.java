package br.ufpb.dcx.animes;

public class AnimeJaExiste extends Exception{
    public AnimeJaExiste(String msg){
        super(msg);
    }
}
