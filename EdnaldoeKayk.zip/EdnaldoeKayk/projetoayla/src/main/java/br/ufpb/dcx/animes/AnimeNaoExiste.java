package br.ufpb.dcx.animes;

public class AnimeNaoExiste extends Exception{
    public AnimeNaoExiste (String msg){
        super(msg);
    }
}
